
Runtime Git Repository Folder
=====================================================================

This folder will be used by git for all repositories whether cloned to created locally.
The security permission defaults will not allow git to create or clone outside of this folder.