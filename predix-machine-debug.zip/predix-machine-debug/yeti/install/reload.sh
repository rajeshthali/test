#!/bin/sh
sleep 120
systemctl --user restart predixmachine