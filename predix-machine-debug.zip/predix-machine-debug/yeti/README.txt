
Yeti is a process that should be started for installing new software. 
This zip to be installed is configured under Device Management, downloaded, and placed in "installations". 
This will be unzipped and Yeti will run any install.sh inside the zip.
